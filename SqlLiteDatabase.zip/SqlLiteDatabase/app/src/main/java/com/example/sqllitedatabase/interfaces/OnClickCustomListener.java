package com.example.sqllitedatabase.interfaces;

public interface OnClickCustomListener {
    public void onClick();
}
